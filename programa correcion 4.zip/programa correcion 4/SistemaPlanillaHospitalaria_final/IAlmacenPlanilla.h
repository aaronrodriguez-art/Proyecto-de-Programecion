#ifndef IALMACENPLANILLA_H
#define IALMACENPLANILLA_H
#include "ListaComprobantes.h"
#include "ListaEmpleado.h"
#include "ListaDepartamento.h"

// Interfaz: dice QUE se puede hacer con el almacenamiento de la planilla,
// pero no COMO (eso lo decide la clase que la implemente, por ejemplo un archivo de texto).
class IAlmacenPlanilla {
public:
	virtual ~IAlmacenPlanilla() {}
	virtual bool guardar(ListaComprobantes* comprobantes) = 0;
	virtual int cargar(ListaComprobantes* comprobantes, ListaEmpleado* empleados, ListaDepartamento* departamentos) = 0;
};

#endif
