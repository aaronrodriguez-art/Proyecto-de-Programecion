#include "Empleado.h"

Empleado::Empleado() {
	
	this->cedula=new int();
	this->nombre=new string();
	this->codigo=new int();
	
}

Empleado::Empleado(int cedula,string nombre,int codigo){
	
	this->cedula=new int(cedula);
	this->nombre=new string (nombre);
	this->codigo=new int (codigo);
	
}

void Empleado::setCedula(int cedula) {delete this-> cedula; this-> cedula = new int(cedula);}
void Empleado::setNombre(string nombre) {delete this-> nombre; this-> nombre = new string(nombre);}
void Empleado::setCodigo(int codigo) {delete this-> codigo; this-> codigo = new int(codigo);}

int Empleado:: getCedula(){return *cedula; }
string Empleado:: getNombre(){return * nombre; }
int Empleado:: getCodigo(){return *codigo; }

string Empleado::toString(){
	stringstream ss;
	ss << "----------Empleado----------"<<endl;
	ss << "Cedula: " << *cedula << endl;
	ss << "Nombre: " << *nombre << endl;
	ss << "Codigo: " << *codigo << endl;
	
	return ss.str();
	
}
Empleado::~Empleado(){
	delete cedula;
	delete nombre;
	delete codigo;
}
	
