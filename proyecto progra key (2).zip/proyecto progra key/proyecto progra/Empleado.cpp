#include "Empleado.h"
#include "medico.h"
#include "enfermero.h"
#include "administracion.h"

Empleado::Empleado() {
	
	this->cedula=new int();
	this->nombre=new string();
	this->codigo=new int();
	
}

Empleado::Empleado(int cedula,string nombre,int codigo){
	
	this->cedula=new int(cedula);
	this->nombre=new string (nombre);
	this->codigo=new int (codigo);
	
}

void Empleado::setCedula(int cedula) {delete this-> cedula; this-> cedula = new int(cedula);}
void Empleado::setNombre(string nombre) {delete this-> nombre; this-> nombre = new string(nombre);}
void Empleado::setCodigo(int codigo) {delete this-> codigo; this-> codigo = new int(codigo);}

int Empleado:: getCedula(){return *cedula; }
string Empleado:: getNombre(){return * nombre; }
int Empleado:: getCodigo(){return *codigo; }

string Empleado::toString(){
	stringstream ss;
	ss << "----------Empleado----------"<<endl;
	ss << "Cedula: " << *cedula << endl;
	ss << "Nombre: " << *nombre << endl;
	ss << "Codigo: " << *codigo << endl;
	
	return ss.str();
	
}
void Empleado::autoGuardar(ofstream& estFile) {
	cout << "    <<Guardando>>" << endl;
	cout << toString() << endl;
	estFile << cedula  << endl
		<< nombre << endl
		<< codigo << endl;
}
Empleado* Empleado::autoLeer(ifstream& estFile) {
	int tipoEmpleado;
	
	if (!(estFile >> tipoEmpleado)) { return NULL; }
	
	if (tipoEmpleado == 1) {
		int cedula, codigo, anosExperiencia;
		string nombre, especialidad, turnoGuardia;
		
		if (!(estFile >> cedula)) { return NULL; }
		if (!(estFile >> nombre)) { return NULL; }
		if (!(estFile >> codigo)) { return NULL; }
		if (!(estFile >> especialidad)) { return NULL; }
		if (!(estFile >> anosExperiencia)) { return NULL; }
		if (!(estFile >> turnoGuardia)) { return NULL; }
		
		cout << "   --Cargando registro" << endl;
		return new medico(cedula, nombre, codigo, especialidad, anosExperiencia, turnoGuardia);
	} 
	else if (tipoEmpleado == 2) {
		int cedula, codigo;
		string nombre, areaAsignada;
		bool estaGuardia;
		
		if (!(estFile >> cedula)) { return NULL; }
		if (!(estFile >> nombre)) { return NULL; }
		if (!(estFile >> codigo)) { return NULL; }
		if (!(estFile >> areaAsignada)) { return NULL; }
		if (!(estFile >> estaGuardia)) { return NULL; }
		
		cout << "   --Cargando registro" << endl;
		return new enfermero(cedula, nombre, codigo, areaAsignada, estaGuardia);
	} 
	else if (tipoEmpleado == 3) {
		int cedula, codigo;
		string nombre, departamento;
		bool accesoFinanciero;
		
		if (!(estFile >> cedula)) { return NULL; }
		if (!(estFile >> nombre)) { return NULL; }
		if (!(estFile >> codigo)) { return NULL; }
		if (!(estFile >> departamento)) { return NULL; }
		if (!(estFile >> accesoFinanciero)) { return NULL; }
		
		cout << "   --Cargando registro" << endl;
		return new administracion(cedula, nombre, codigo, departamento, accesoFinanciero);
	}
	
	return NULL;
}

Empleado::~Empleado(){
	delete cedula;
	delete nombre;
	delete codigo;
}
	
