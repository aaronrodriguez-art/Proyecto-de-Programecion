#include <iostream>
#include <iomanip>
#include "medico.h"
#include "enfermero.h"
#include "administracion.h"

using namespace std;

int main() {
	cout << fixed << setprecision(2);
	
	medico m(301110222, "Carlos Perez", 101, "Cardiologia", 5, "Nocturno");
	enfermero e(402220333, "Maria Rodriguez", 202, "Cuidados Intensivos", true);
	administracion a(503330404, "Juan Gomez", 303, "Recursos Humanos", true);
	
	cout << m.toString() << endl;
	cout << "Salario Neto: " << m.calcularSalario() << endl;
	cout << "---------------------------------------" << endl;
	
	cout << e.toString() << endl;
	cout << "Salario Neto: " << e.calcularSalario() << endl;
	cout << "---------------------------------------" << endl;
	
	cout << a.toString() << endl;
	cout << "Salario Neto: " << a.calcularSalario() << endl;
	cout << "---------------------------------------" << endl;
	
	return 0;
}
