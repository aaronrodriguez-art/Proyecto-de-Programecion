#include "GestionDepartamento.h"

GestionDepartamento::GestionDepartamento() {
	this->departamentos = new ListaDepartamento;
	this->archivo = new ArchivoDepartamento;
}

GestionDepartamento::~GestionDepartamento() {
	delete archivo;
	delete departamentos;
}

void GestionDepartamento::registrarDepartamento(Departamento* d) {
	departamentos->insertarInicio(d);
}

string GestionDepartamento::mostrarDepartamento() {
	return departamentos->toString();
}

void GestionDepartamento::guardarDepartamento() {
	archivo->guardarDepartamento(departamentos);
}

void GestionDepartamento::cargarDepartamento() {
	archivo->cargarDepartamento(departamentos);
}
